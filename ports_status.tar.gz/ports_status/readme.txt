Application Name
================
ports_status


Application Version
===================
1.10


NCOS Devices Supported
======================
ALL


External Requirements
=====================


Application Purpose
===================
This application will set the device description to visually show
the LAN/WAN/WWAN/Modem/IP Verify status


Expected Output
===============
Description updated
Log printed

