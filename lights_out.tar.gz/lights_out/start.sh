#!/bin/bash
cppython lights_out.py