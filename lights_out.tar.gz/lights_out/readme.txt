Application Name
================
lights_out


Application Version
===================
1.0


NCOS Devices Supported
======================
ALL


External Requirements
=====================
None


Application Purpose
===================
Turn off E-Series light bar


Expected Output
===============
Darkness

